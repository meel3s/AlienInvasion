import pygame as pg
from pygame.sprite import Sprite


class Aliens:
    def __init__(self, settings, screen, alien_group, ship_height, game):
        self.settings = settings
        self.aliens = alien_group
        self.screen = screen
        self.game = game
        self.ship_height = ship_height
        self.create_fleet()

    def create_fleet(self):
        settings, screen = self.settings, self.screen
        alien = Alien(settings=settings, screen=self.screen)
        alien_width = alien.rect.width
        alien_height = alien.rect.height
        aliens_per_row = self.aliens_per_row(settings=settings, alien_width=alien_width)
        rows_per_screen = self.rows_per_screen(settings=settings, alien_height=alien_height)

        for y in range(rows_per_screen):
            for x in range(aliens_per_row):
                alien = Alien(settings=settings, screen=screen, x=alien_width + 2 * alien_width * x,
                              y=alien_height + 2 * alien_height * y)
                self.aliens.add(alien)

    def aliens_per_row(self, settings, alien_width):
        space_x = settings.screen_width - 2 * alien_width
        return int(space_x / (2 * alien_width))

    def rows_per_screen(self, settings, alien_height):
        space_y = settings.screen_height - (3 * alien_height) - self.ship_height
        return int(space_y / (2 * alien_height))

    def add(self, alien): self.aliens.add(alien)

    def change_direction(self):
        for alien in self.aliens:
            alien.rect.y += self.settings.fleet_drop_speed
        self.settings.fleet_direction *= -1

    def check_edges(self):
        for alien in self.aliens:
            if alien.check_edges(): return True
        return False

    def check_aliens_bottom(self):
        r = self.screen.get_rect()
        for alien in self.aliens.sprites():
            if alien.rect.bottom > r.bottom:
                return True
        return False

    def update(self):
        self.aliens.update()
        if self.check_edges(): self.change_direction()
        if self.check_aliens_bottom() or pg.sprite.spritecollideany(self.game.ship, self.aliens):
            print("Resetting game")
            self.game.reset()
            return
        for alien in self.aliens.copy():
            alien.update()
            if alien.rect.bottom <= 0: self.aliens.remove(alien)

    def draw(self):
        for alien in self.aliens.sprites(): alien.draw()



class Alien(Sprite):   # INHERITS from SPRITE
    def __init__(self, settings, screen, number=0, x=0, y=0, speed=0):
        super().__init__()
        self.screen = screen
        self.settings = settings
        self.number = number

        self.image = pg.image.load('images/alien.bmp')
        self.rect = self.image.get_rect()

        self.rect.x = self.x = x
        self.rect.y = self.y = y
        # self.rect.x = self.rect.width
        # self.rect.y = self.rect.height

        self.x = float(self.rect.x)
        self.speed = speed

    def check_edges(self):
        r, rscreen = self.rect, self.screen.get_rect()
        return r.right >= rscreen.right or r.left <= 0

    def update(self):
        delta = self.settings.alien_speed * self.settings.fleet_direction
        self.rect.x += delta
        self.x = self.rect.x

    def draw(self):
        self.screen.blit(self.image, self.rect)